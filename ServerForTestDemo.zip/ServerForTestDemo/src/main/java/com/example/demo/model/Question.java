package com.example.demo.model;

public class Question {

	private int QId;
	private String Question;
	private String Option_A;

	private String Option_B;

	private String Option_C;

	private String Option_D;

	private String Right_Ans;

	public int getQId() {
		return QId;
	}

	public void setQId(int qId) {
		QId = qId;
	}

	

	public String getQuestion() {
		return Question;
	}

	public void setQuestion(String question) {
		Question = question;
	}

	public String getOption_A() {
		return Option_A;
	}

	public void setOption_A(String option_A) {
		Option_A = option_A;
	}

	public String getOption_B() {
		return Option_B;
	}

	public void setOption_B(String option_B) {
		Option_B = option_B;
	}

	public String getOption_C() {
		return Option_C;
	}

	public void setOption_C(String option_C) {
		Option_C = option_C;
	}

	public String getOption_D() {
		return Option_D;
	}

	public void setOption_D(String option_D) {
		Option_D = option_D;
	}

	public String getRight_Ans() {
		return Right_Ans;
	}

	public void setRight_Ans(String right_Ans) {
		Right_Ans = right_Ans;
	}
}
