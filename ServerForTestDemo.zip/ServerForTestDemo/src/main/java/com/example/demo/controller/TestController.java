package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Question;

@RestController
@CrossOrigin("*")
public class TestController {

	@GetMapping
	@RequestMapping("/getQuesion")
	public List<Question> getAllQuestion(){
		List<Question> l=new ArrayList<Question>();
		Question q=new Question();
		q.setQId(1);
		q.setQuestion("What is hibernate");
		q.setOption_A("ORM tool");
		q.setOption_B("JDBC Tool");
		q.setOption_C("Dont know");
		q.setOption_D("All of this");
		q.setRight_Ans("A");
		l.add(q);
		Question q1=new Question();
		q1.setQId(2);
		q1.setQuestion("What is oops");
		q1.setOption_A("Java feature");
		q1.setOption_B("PHP feature");
		q1.setOption_C("Dont know");
		q1.setOption_D("All of this");
		q1.setRight_Ans("A");
		l.add(q1);
		return l;
	}
	
}
